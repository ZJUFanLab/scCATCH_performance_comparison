library(testthat)
library(scCATCH)

test_check("scCATCH")
